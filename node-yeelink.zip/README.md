node-yeelink
============

Nodejs SDK for yeelink


And a simple for the SDK.

Monitor your system cpu usage and memory usage and upload the data to yeelink.

Use yeelink to control your system.
